"""
Test Langchain Agent - FastAPI service with platform LLM proxy integration
This service demonstrates a Langchain agent that uses the A2A platform's LLM proxy.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional, AsyncGenerator
import json
import asyncio
import logging
import sys
import os
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)
logger = logging.getLogger(__name__)

app = FastAPI(title="Test Langchain Agent")

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    """Request model for chat endpoint"""
    input: str
    config: Optional[dict] = None


class ChatResponse(BaseModel):
    """Response model for blocking chat endpoint"""
    output: str


def get_llm_proxy_config():
    """
    Get LLM proxy configuration from environment variables.
    These should be set to the platform's LLM proxy endpoint and API key.

    The platform provides these via:
    - PLATFORM_LLM_ENDPOINT: http://localhost:9050/api/llm/trace/{trace_id}/v1
    - PLATFORM_API_KEY: API key from platform settings
    """
    llm_endpoint = os.getenv("PLATFORM_LLM_ENDPOINT")
    api_key = os.getenv("PLATFORM_API_KEY", "dummy-key-for-platform")

    if not llm_endpoint:
        logger.warning(
            "PLATFORM_LLM_ENDPOINT not set. "
            "This should be the platform's LLM proxy endpoint. "
            "Using default endpoint for testing."
        )
        llm_endpoint = "http://localhost:9050/api/llm/v1"

    logger.info(f"Using LLM endpoint: {llm_endpoint}")
    return llm_endpoint, api_key


def create_chain():
    """
    Create a Langchain chain using the platform's LLM proxy
    """
    llm_endpoint, api_key = get_llm_proxy_config()

    # Create LLM client pointing to platform's proxy
    # The platform proxy supports OpenAI-compatible API
    llm = ChatOpenAI(
        base_url=llm_endpoint,
        api_key=api_key,
        model="qwen/qwen3-14b",  # or any model available in platform
        temperature=0.7,
        streaming=True,
    )

    # Create a simple prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful AI assistant integrated with the A2A platform. "
                  "When explaining your reasoning, wrap it in <think> tags. "
                  "For example: <think>Let me analyze this...</think> Here's my response."),
        ("human", "{input}"),
    ])

    # Create chain
    chain = prompt | llm | StrOutputParser()

    return chain


async def generate_streaming_response(message: str) -> AsyncGenerator[str, None]:
    """
    Generate a streaming response using Langchain and platform LLM proxy
    """
    logger.info(f"Processing message: {message}")

    try:
        chain = create_chain()

        # Stream the response
        async for chunk in chain.astream({"input": message}):
            if chunk:
                yield "data: " + json.dumps({"output": chunk}) + "\n\n"
                await asyncio.sleep(0.01)  # Small delay for smoother streaming

        # Send completion signal
        yield "data: [DONE]\n\n"
        logger.info("Response generation completed")

    except Exception as e:
        logger.error(f"Error generating response: {e}")
        yield "data: " + json.dumps({"error": str(e)}) + "\n\n"


async def generate_blocking_response(message: str) -> str:
    """
    Generate a complete response using Langchain and platform LLM proxy
    """
    logger.info(f"Processing blocking message: {message}")

    try:
        chain = create_chain()

        # Get complete response
        response = await chain.ainvoke({"input": message})
        logger.info("Blocking response generated")
        return response

    except Exception as e:
        logger.error(f"Error generating response: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/invoke", response_model=ChatResponse)
async def invoke_blocking(request: ChatRequest):
    """
    Blocking endpoint - returns complete response at once
    Compatible with JSON response format
    Uses platform LLM proxy with tracing
    """
    logger.info(f"Blocking invoke called with input: {request.input}")

    response = await generate_blocking_response(request.input)

    return ChatResponse(output=response)


@app.post("/invoke/stream")
async def invoke_streaming(request: ChatRequest):
    """
    Streaming endpoint - returns response via SSE
    Compatible with SSE streaming format
    Uses platform LLM proxy with tracing
    """
    logger.info(f"Streaming invoke called with input: {request.input}")

    return StreamingResponse(
        generate_streaming_response(request.input),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",  # Disable buffering in nginx
        }
    )


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    llm_endpoint, _ = get_llm_proxy_config()
    return {
        "status": "healthy",
        "service": "test-langchain-agent",
        "llm_endpoint": llm_endpoint
    }


@app.get("/")
async def root():
    """Root endpoint with service information"""
    llm_endpoint, _ = get_llm_proxy_config()
    return {
        "service": "Test Langchain Agent",
        "version": "1.0.0",
        "llm_endpoint": llm_endpoint,
        "endpoints": {
            "/invoke": "POST - Blocking chat endpoint",
            "/invoke/stream": "POST - Streaming chat endpoint (SSE)",
            "/health": "GET - Health check",
        },
        "request_format": {
            "input": "string (required) - User message",
            "config": "object (optional) - Additional configuration"
        },
        "features": [
            "SSE streaming support",
            "<think> tag reasoning content",
            "Platform LLM proxy integration",
            "Automatic tracing via platform proxy",
            "CORS enabled for local development",
            "Compatible with A2A platform Langchain adapter"
        ],
        "configuration": {
            "PLATFORM_LLM_ENDPOINT": "Set to platform's LLM proxy endpoint",
            "PLATFORM_API_KEY": "Set to platform API key (optional)"
        }
    }


if __name__ == "__main__":
    import uvicorn

    logger.info("Starting Test Langchain Agent server...")
    logger.info("=" * 60)
    logger.info("Configuration:")
    logger.info(f"  LLM Endpoint: {os.getenv('PLATFORM_LLM_ENDPOINT', 'Not set')}")
    logger.info(f"  API Key: {'Set' if os.getenv('PLATFORM_API_KEY') else 'Not set'}")
    logger.info("=" * 60)

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8765,
        log_level="info"
    )
